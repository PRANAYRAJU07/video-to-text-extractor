from flask import Flask, request, render_template, redirect, url_for
import moviepy.editor as mp
import speech_recognition as sr
import os

app = Flask(__name__)

# Route for home page and form submission
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if "video_file" not in request.files:
            return "No video file part"
        
        file = request.files["video_file"]
        
        if file.filename == "":
            return "No selected file"
        
        if file:
            file_path = os.path.join("uploads", file.filename)
            file.save(file_path)

            # Convert video to audio
            video = mp.VideoFileClip(file_path)
            audio_file_path = os.path.join("uploads", "audio.wav")
            video.audio.write_audiofile(audio_file_path)

            # Recognize speech from audio
            recognizer = sr.Recognizer()
            with sr.AudioFile(audio_file_path) as source:
                audio_data = recognizer.record(source)
                try:
                    text = recognizer.recognize_google(audio_data)
                except sr.UnknownValueError:
                    text = "Could not understand audio"
                except sr.RequestError:
                    text = "Could not request results from Google Speech Recognition"

            return render_template("result.html", text=text)
    
    return render_template("index.html")

if __name__ == "__main__":
    if not os.path.exists("uploads"):
        os.makedirs("uploads")
    app.run(debug=True)
